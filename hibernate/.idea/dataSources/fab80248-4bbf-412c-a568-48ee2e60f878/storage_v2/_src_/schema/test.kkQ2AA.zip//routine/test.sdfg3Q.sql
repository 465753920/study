CREATE PROCEDURE test(IN num INT)
  BEGIN
	select mylog('123');
END;

