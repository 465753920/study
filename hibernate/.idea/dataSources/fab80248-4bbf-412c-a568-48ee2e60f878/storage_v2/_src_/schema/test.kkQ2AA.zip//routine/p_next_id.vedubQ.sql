CREATE PROCEDURE p_next_id(IN i_name VARCHAR(255), IN i_age INT, OUT o_result INT)
  BEGIN 
	SET @id= NULL;
	SET @name= NULL;
	SELECT id INTO @id FROM userinfo WHERE age= i_age;
	select name into @name from userinfo where age=i_age;
	select @id,@name;
	SELECT @id INTO o_result;
END;

