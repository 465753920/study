CREATE PROCEDURE dorepeat(IN p1 INT)
  BEGIN
    SET @x = 0;
    REPEAT 
        INSERT INTO example VALUES (@x,'testValue','testValue','testValue');
        SET @x = @x + 1; 
    UNTIL @x > p1 END REPEAT;
END;

