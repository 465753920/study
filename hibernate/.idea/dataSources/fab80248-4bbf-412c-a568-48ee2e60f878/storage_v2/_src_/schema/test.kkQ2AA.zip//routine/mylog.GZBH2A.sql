CREATE FUNCTION mylog(message VARCHAR(255))
  RETURNS VARCHAR(255)
  BEGIN
	insert into log (time, text) values (NOW(), message);
	RETURN '';
END;

